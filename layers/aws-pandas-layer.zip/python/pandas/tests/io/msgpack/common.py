frombytes = lambda obj, data: obj.frombytes(data)
tobytes = lambda obj: obj.tobytes()
